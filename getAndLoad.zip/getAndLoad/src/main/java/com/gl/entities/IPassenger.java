package com.gl.entities;

public interface IPassenger {
	public int getPassengerNo();
	public void setPassengerNo(int passengerNo);
	public String getPassengerName();
	public void setPassengerName(String passengerName);
	public int getAge();
	public void setAge(int age);
	public String getGender();
	public void setGender(String gender);
}
